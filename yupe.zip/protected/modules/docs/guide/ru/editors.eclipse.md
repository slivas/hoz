# Работа с eclipse #

### Пробелы вместо табуляций
windows -> preferences -> general -> editors -> text editors -> ставим галочку на insert spaces for tabs

windows -> preferences -> PHP -> code style -> formatter -> выставляем tab policy = spaces, indentation size = 4

### Устанавливаем Aptana Studio 3 Plugin
help -> install new software... -> add -> location = http://download.aptana.com/studio3/plugin/install -> ok -> выбираем нужные компоненты и устанавливаем.

### Настройка форматирования в aptana studio
windows -> preferences -> aptana studio -> formatter -> import ... -> [выбираем файл](http://narod.ru/disk/48095872001.1641375368365b1634babfaed26109ac/Yii.xml.html) -> ok

Запуск форматирования CTRL+SHIFT+F

### Установка git (EGit и JGit)
help -> install new software... -> add -> location = http://download.eclipse.org/egit/updates-1.0 -> ok -> выбираем нужные компоненты и устанавливаем.