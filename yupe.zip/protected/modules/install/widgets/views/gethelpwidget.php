<div class="alert alert-block alert-notice">
    <p><b><?php echo Yii::t('InstallModule.install','If you have problems with installation, please check {link} or {feedback}',array(
                '{link}' => CHtml::link(Yii::t('InstallModule.install','our forum'),'http://yupe.ru/talk/viewforum.php?id=10',array('target' => '_blank')),
                '{feedback}' => CHtml::link(Yii::t('InstallModule.install','contact us'),'http://yupe.ru/contacts?from=install',array('target' => '_blank')),
            ));?></b></p>
</div>