<?php
return array(
    'Users' => 'Пользователи',
    'Socialization' => 'Социализация',
    'Module for login and registration via social networks' => 'Модуль для входа и регистрации через социальные сети',
    'Accounts' => 'Аккаунты',
    'User' => 'Пользователь',
    'Service' => 'Сервис',
    'Uuid' => 'Uuid',
    'User name' => 'Имя пользователя',
    'Email' => 'Email'
);